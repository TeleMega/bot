rocks_trees = {
   { name = [[system]], root = [[/home/cabox/workspace/telediamond/.luarocks]] }
}
